from django.apps import AppConfig


class MyproductConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Myproduct'
