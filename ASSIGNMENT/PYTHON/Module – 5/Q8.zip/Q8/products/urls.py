from django.urls import path
from django.contrib.auth.views import LogoutView

from .views import *

urlpatterns = [
    path('base/',base_page,name='base_page'),
    path('home/', home, name='home'),
    path('admin/home/', admin_home, name='admin_home'),
    path('manager/home/',manager_home, name='manager_home'),
    path('ragister/',register, name='register'),
    path('',login, name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),

    # Admin product management URLs
    path('admin/products/', product_list_admin, name='product_list_admin'),
    path('admin/products/create/', product_create, name='product_create'),
    path('admin/products/<int:pk>/edit/', product_update, name='product_update'),
    path('admin/products/<int:pk>/delete/', product_delete, name='product_delete'),

    # Admin product subcategory management URLs
    path('admin/product-subcategories/', product_subcategory_list_admin, name='product_subcategory_list_admin'),
    path('admin/product-subcategories/create/', product_subcategory_create, name='product_subcategory_create'),
    path('admin/product-subcategories/<int:pk>/edit/', product_subcategory_update, name='product_subcategory_update'),
    path('admin/product-subcategories/<int:pk>/delete/',product_subcategory_delete, name='product_subcategory_delete'),

    # Manager product search URL
    path('manager/products/', product_search, name='product_search'),
]
