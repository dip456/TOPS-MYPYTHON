from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login as auth_login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .forms import UserRegisterForm, ProductForm, ProductSubCategoryForm
from .models import Product, ProductSubCategory

# Helper functions to check roles
def is_admin(user):
    return user.groups.filter(name='Admin').exists()

def is_manager(user):
    return user.groups.filter(name='Manager').exists()

def base_page(request):
    return render(request,'products/base.html')

@login_required
def home(request):
    if is_admin(request.user):
        return redirect('admin_home')
    elif is_manager(request.user):
        return redirect('manager_home')
    return render(request, 'products/home.html')

@login_required
@user_passes_test(is_admin)
def admin_home(request):
    return render(request, 'products/admin_home.html')

@login_required
@user_passes_test(is_manager)
def manager_home(request):
    return render(request, 'products/manager_home.html')

# Registration and login views
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, f'Account created for {user.username}!')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'products/register.html', {'form': form})

def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.info(request, f'You are now logged in as {username}.')
                return redirect('home')
            else:
                messages.error(request, 'Invalid username or password.')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'products/login.html', {'form': form})

# Product management views for Admin
@login_required
@user_passes_test(is_admin)
def product_list_admin(request):
    products = Product.objects.all()
    return render(request, 'products/product_list_admin.html', {'products': products})

@login_required
@user_passes_test(is_admin)
def product_create(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('product_list_admin')
    else:
        form = ProductForm()
    return render(request, 'products/product_form.html', {'form': form})

@login_required
@user_passes_test(is_admin)
def product_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('product_list_admin')
    else:
        form = ProductForm(instance=product)
    return render(request, 'products/product_form.html', {'form': form})

@login_required
@user_passes_test(is_admin)
def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        return redirect('product_list_admin')
    return render(request, 'products/product_confirm_delete.html', {'product': product})

@login_required
@user_passes_test(is_admin)
def product_subcategory_list_admin(request):
    subcategories = ProductSubCategory.objects.all()
    return render(request, 'products/product_subcategory_list_admin.html', {'subcategories': subcategories})

@login_required
@user_passes_test(is_admin)
def product_subcategory_create(request):
    if request.method == 'POST':
        form = ProductSubCategoryForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('product_subcategory_list_admin')
    else:
        form = ProductSubCategoryForm()
    return render(request, 'products/product_subcategory_form.html', {'form': form})

@login_required
@user_passes_test(is_admin)
def product_subcategory_update(request, pk):
    subcategory = get_object_or_404(ProductSubCategory, pk=pk)
    if request.method == 'POST':
        form = ProductSubCategoryForm(request.POST, request.FILES, instance=subcategory)
        if form.is_valid():
            form.save()
            return redirect('product_subcategory_list_admin')
    else:
        form = ProductSubCategoryForm(instance=subcategory)
    return render(request, 'products/product_subcategory_form.html', {'form': form})

@login_required
@user_passes_test(is_admin)
def product_subcategory_delete(request, pk):
    subcategory = get_object_or_404(ProductSubCategory, pk=pk)
    if request.method == 'POST':
        subcategory.delete()
        return redirect('product_subcategory_list_admin')
    return render(request, 'products/product_subcategory_confirm_delete.html', {'subcategory': subcategory})

# Product search view for Manager
@login_required
@user_passes_test(is_manager)
def product_search(request):
    query = request.GET.get('q')
    subcategories = ProductSubCategory.objects.filter(product__name__icontains=query) if query else ProductSubCategory.objects.all()
    return render(request, 'products/product_search.html', {'subcategories': subcategories})

# Create your views here.
