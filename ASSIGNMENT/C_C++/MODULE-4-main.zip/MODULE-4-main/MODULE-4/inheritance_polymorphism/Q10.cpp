/*11. Write a program to calculate the area of circle, rectangle and triangle 
using Function Overloading 
Rectangle: Area * 
breadth Triangle: ½ 
*Area* breadth Circle: 
Pi * Area *Area*/